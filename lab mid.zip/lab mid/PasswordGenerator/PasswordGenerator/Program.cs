﻿using System;
using System.Text;
using System.Text.RegularExpressions;

public class PasswordGenerator
{
    public static void Main()
    {
        string registrationNumber = "26";
        string firstName = "Arslan";
        string lastName = "Ahmed";
        string favoriteMovie = "Avengers";

        string password = GeneratePassword(registrationNumber, firstName, lastName, favoriteMovie);
        Console.WriteLine("Generated Password: " + password);
    }

    private static string GeneratePassword(string regNo, string fName, string lName, string favMovie)
    {
        string pattern = @"^(?=.*\d{2})(?=.*[a-zA-Z]{2})(?=.*[@$%&*!])(?!.*[#]).{14}$";
        Regex regex = new Regex(pattern);

        Random rnd = new Random();
        string password;

        do
        {
            string regDigits = ExtractTwoDigits(regNo);

            string nameLetters = (fName.Length > 1 ? fName[1].ToString() : "") +
                                 (lName.Length > 1 ? lName[1].ToString() : "");

            string movieChars = favMovie.Substring(0, 2);

            string specialChars = "@$%&*!";

            char specialChar1 = specialChars[rnd.Next(specialChars.Length)];

            StringBuilder passwordBuilder = new StringBuilder();
            passwordBuilder.Append(regDigits);
            passwordBuilder.Append(nameLetters);
            passwordBuilder.Append(movieChars);
            passwordBuilder.Append(specialChar1);

            string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            while (passwordBuilder.Length < 14)
            {
                passwordBuilder.Append(alphabet[rnd.Next(alphabet.Length)]);
            }

            password = passwordBuilder.ToString();

        } while (!regex.IsMatch(password));

        return password;
    }

    private static string ExtractTwoDigits(string input)
    {
        StringBuilder digits = new StringBuilder();
        foreach (char c in input)
        {
            if (char.IsDigit(c))
            {
                digits.Append(c);
                if (digits.Length == 2)
                {
                    break;
                }
            }
        }
        return digits.ToString().PadRight(2, '0');
    }
}
